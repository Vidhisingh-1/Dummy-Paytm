
export default function() {
    return <div className="w-full flex flex-col pt-60 space-y-6 h-screen text-4xl font-bold">
        <div className="flex justify-center text-[#6a51a6]">WELCOME</div>
        <div className="flex justify-center text-[#6a51a6]">To</div>
        <div className="flex justify-center text-[#6a51a6]">PayTm 2.0</div>
    </div>
}